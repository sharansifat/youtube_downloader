import logging
from flask import Flask, render_template, request, send_file, redirect, url_for, flash
from pytube import YouTube, exceptions
import os
from io import BytesIO
import ssl
import certifi
import urllib.request

# Set up logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Required for flash messages

# Set up SSL context to use certifi certificates
ssl_context = ssl.create_default_context(cafile=certifi.where())
urllib.request.install_opener(urllib.request.build_opener(urllib.request.HTTPSHandler(context=ssl_context)))


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/download', methods=['POST'])
def download():
    url = request.form['url']
    itag = request.form['itag']
    try:
        yt = YouTube(url)
        stream = yt.streams.get_by_itag(itag)

        buffer = BytesIO()
        stream.stream_to_buffer(buffer)
        buffer.seek(0)

        filename = yt.title + ('.mp4' if stream.mime_type == 'video/mp4' else '.mp3')

        return send_file(buffer, as_attachment=True, download_name=filename, mimetype=stream.mime_type)
    except exceptions.PytubeError as e:
        logging.error(f"A PyTube error occurred: {e}")
        flash(f"A PyTube error occurred: {e}")
        return redirect(url_for('index'))
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        flash(f"An error occurred: {e}")
        return redirect(url_for('index'))


@app.route('/get_streams', methods=['POST'])
def get_streams():
    url = request.form['url']
    try:
        yt = YouTube(url)
        streams = yt.streams.filter(only_audio=True) if request.form['type'] == 'audio' else yt.streams.filter(
            progressive=True)

        return render_template('streams.html', streams=streams, url=url, type=request.form['type'])
    except exceptions.PytubeError as e:
        logging.error(f"A PyTube error occurred: {e}")
        flash(f"A PyTube error occurred: {e}")
        return redirect(url_for('index'))
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        flash(f"An error occurred: {e}")
        return redirect(url_for('index'))


if __name__ == '__main__':
    app.run(debug=True, port=5002)  # Change the port here
